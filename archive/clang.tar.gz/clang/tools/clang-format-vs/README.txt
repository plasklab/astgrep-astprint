This directory contains a VSPackage project to generate a Visual Studio extension
for clang-format.

Build prerequisites are:
- Visual Studio 2012 Professional
- Visual Studio SDK (http://www.microsoft.com/en-us/download/details.aspx?id=30668)
