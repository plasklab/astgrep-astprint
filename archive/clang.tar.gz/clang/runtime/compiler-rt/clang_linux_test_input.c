// This file is used to check if we can produce working executables
// for i386 and x86_64 archs on Linux.
#include <stdlib.h>
int main(){}
